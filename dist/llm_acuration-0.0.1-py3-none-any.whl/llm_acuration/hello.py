def hello():
    print("Hello, Acuration World!")