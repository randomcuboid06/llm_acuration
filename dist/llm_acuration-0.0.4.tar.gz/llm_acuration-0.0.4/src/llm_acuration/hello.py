def hello():
    """
    This is just a placeholder function
    
    You can access this documentation by using __doc__ on the function or by using help()
    """
    print("Hello, Acuration World!")