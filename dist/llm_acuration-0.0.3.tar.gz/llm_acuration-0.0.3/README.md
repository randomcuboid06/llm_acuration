First version of Acuration's LLM library

Try it out
```
pip install llm-acuration
```

```
from llm_acuration.hello import hello
hello()
```
Prints "Hello, Acuration World!"

You can use help() on functions to know more about them